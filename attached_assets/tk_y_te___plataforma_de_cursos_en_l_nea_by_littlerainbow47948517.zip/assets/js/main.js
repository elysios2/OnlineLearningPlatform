// Enhanced Client-Side Routing and Site Interaction

// Import necessary modules
import { Auth } from '../modules/auth.js';
import { App } from '../modules/app.js';
import { ScrollAnimations } from '../modules/scroll-animations.js'; // Ensure this is correctly imported
import { Home } from '../modules/home.js'; // Import the new Home module

document.addEventListener('DOMContentLoaded', function() {
    // Global Site Configuration - Keep essential configurations
    const SiteConfig = {
        pages: {
            login: '/login.html',
            registro: '/registro.html',
            'curso-detalle': '/course-detail.html',
            catalogo: '/catalog.html',
            'panel-usuario': '/user-panel.html',
            inicio: '/index.html'
        },
        activeUser: null
    };

    // Dynamic Content Loading
    function loadDynamicContent() {
        const urlParams = new URLSearchParams(window.location.search);
        const courseId = urlParams.get('course');
        
        if (courseId && document.querySelector('.course-detail-container')) {
            populateCourseDetails(courseId);
        }
    }

    // Populate Course Details
    function populateCourseDetails(courseId) {
        const courseDetails = {
            'web-fullstack': {
                title: 'Desarrollo Web Fullstack',
                description: 'Curso completo de desarrollo web desde cero',
                price: '$99.99',
                videoUrl: 'https://www.youtube.com/embed/K9qMm3iVc_E'
            },
            'marketing-digital': {
                title: 'Marketing Digital',
                description: 'Estrategias avanzadas de marketing online',
                price: '$79.99',
                videoUrl: 'https://www.youtube.com/embed/VeRj4-sRWYE'
            },
            'ux-ui': {
                title: 'Diseño UX/UI',
                description: 'Diseño de interfaces centrado en la experiencia',
                price: '$89.99',
                videoUrl: 'https://www.youtube.com/embed/KRCfgxi1eKU'
            }
        };

        const course = courseDetails[courseId];
        if (course) {
            document.querySelector('h1').textContent = course.title;
            document.querySelector('.course-description').textContent = course.description;
            document.querySelector('.course-price').textContent = course.price;
            
            const videoContainer = document.querySelector('.course-video-container');
            if (videoContainer) {
                videoContainer.innerHTML = `
                    <iframe 
                        width="560" 
                        height="315" 
                        src="${course.videoUrl}" 
                        title="${course.title}" 
                        frameborder="0" 
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                        allowfullscreen
                    ></iframe>
                `;
            }
        }
    }

    // Initialize Site Interactions
    function initializeSite() {
        loadDynamicContent();
        Home.init(); // Initialize the Home module
    }

    // Run Site Initialization
    initializeSite();
});