// Navigation Module
export const Navigation = {
    init() {
        this.setupBurgerMenu();
        this.setupUniversalNavigation(); // Ensure this is called to initialize navigation
    },

    setupBurgerMenu() {
        const burgerIcon = document.getElementById('burger-icon');
        const menu = document.getElementById('mobile-menu');

        if (burgerIcon && menu) {
            burgerIcon.addEventListener('click', () => {
                menu.classList.toggle('hidden');
            });
        }
    },

    setupUniversalNavigation() {
        // Universal Navigation Handler
        const pageLinks = document.querySelectorAll('a[data-page], [data-page]');
        pageLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const pageKey = this.getAttribute('data-page');
                if (pageKey) {
                    Navigation.navigateTo(pageKey); // Use Navigation.navigateTo
                }
            });
        });

        const courseCards = document.querySelectorAll('.course-card');
        courseCards.forEach(card => {
            card.addEventListener('click', function() {
                const courseId = this.getAttribute('data-course-id');
                if (courseId) {
                    Navigation.navigateToCourseDetail(courseId); // Use Navigation.navigateToCourseDetail
                }
            });
        });
    },

    // Page Navigation Function
    navigateTo(pageKey) {
        const SiteConfig = { // Define SiteConfig here or import it if needed
            pages: {
                login: '/login.html',
                registro: '/registro.html',
                'curso-detalle': '/course-detail.html',
                catalogo: '/catalog.html',
                'panel-usuario': '/user-panel.html',
                inicio: '/index.html'
            }
        };
        const pageUrl = SiteConfig.pages[pageKey];
        if (pageUrl) {
            window.location.href = pageUrl;
        } else {
            console.warn(`No route defined for page: ${pageKey}`);
        }
    },

    // Course Detail Navigation
    navigateToCourseDetail(courseId) {
        window.location.href = `/course-detail.html?course=${courseId}`;
    }
};

document.addEventListener('DOMContentLoaded', () => {
    Navigation.init();
});