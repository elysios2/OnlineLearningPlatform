// Courses Module
import { supabase } from '../config/supabaseClient.js';

export const Courses = {
    async getAllCourses() {
        try {
            const { data, error } = await supabase
                .from('courses')
                .select('*');

            if (error) throw error;

            return data;
        } catch (error) {
            console.error('Get courses error:', error);
            return [];
        }
    },

    async getCourseById(courseId) {
        try {
            const { data, error } = await supabase
                .from('courses')
                .select('*')
                .eq('id', courseId)
                .single();

            if (error) throw error;

            return data;
        } catch (error) {
            console.error('Get course error:', error);
            return null;
        }
    },

    async enrollUserInCourse(courseId) {
        try {
            const user = await Auth.getCurrentUser();
            if (!user) throw new Error('No authenticated user');

            const { data, error } = await supabase
                .from('user_courses')
                .insert({
                    user_id: user.id,
                    course_id: courseId
                });

            if (error) throw error;

            return { success: true, data };
        } catch (error) {
            console.error('Enroll in course error:', error);
            return { success: false, error: error.message };
        }
    }
};

