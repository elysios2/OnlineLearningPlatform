// Home Module
export const Home = {
    init() {
        this.setupAnimatedSlogan();
    },

    setupAnimatedSlogan() {
        const esloganElement = document.getElementById('eslogan-dinamico');
        const esloganTexts = [
            'TU VELOCIDAD.',
            'TU COMPRENSIÓN.',
            'TU FUTURO.'
        ];
        let currentEsloganIndex = 0;

        function updateEslogan() {
            esloganElement.classList.add('opacity-0');
            setTimeout(() => {
                esloganElement.textContent = `CON TK&TE POTENCIA ${esloganTexts[currentEsloganIndex]}`;
                esloganElement.classList.remove('opacity-0');
                currentEsloganIndex = (currentEsloganIndex + 1) % esloganTexts.length;
            }, 500);
        }

        // Initial setup
        esloganElement.textContent = `CON TK&TE POTENCIA ${esloganTexts[0]}`;

        // Change eslogan every 5 seconds
        setInterval(updateEslogan, 5000);
    }
};