// Main Application Module
import { Auth } from './auth.js';
import { User } from './user.js';
import { Courses } from './courses.js';
import { Progress } from './progress.js';
import { UI } from './ui.js';

export const App = {
    init() {
        this.setupGlobalNavigation();
        this.setupAuthButtons();
        this.checkAuthStatus();
    },

    setupGlobalNavigation() {
        // Universal navigation handler for all pages
        document.addEventListener('click', (event) => {
            const navTarget = event.target.closest('[data-nav]');
            if (navTarget) {
                const destination = navTarget.getAttribute('data-nav');
                switch(destination) {
                    case 'login':
                        window.location.href = '/login.html';
                        break;
                    case 'registro':
                        window.location.href = '/registro.html';
                        break;
                    case 'cursos':
                        window.location.href = '/catalog.html';
                        break;
                    case 'panel-usuario':
                        window.location.href = '/user-panel.html';
                        break;
                    case 'inicio':
                        window.location.href = '/index.html';
                        break;
                }
            }
        });
    },

    setupAuthButtons() {
        // Setup login/registro buttons across all pages
        const loginButtons = document.querySelectorAll('[data-nav="login"]');
        const registroButtons = document.querySelectorAll('[data-nav="registro"]');

        loginButtons.forEach(btn => {
            btn.addEventListener('click', () => window.location.href = '/login.html');
        });

        registroButtons.forEach(btn => {
            btn.addEventListener('click', () => window.location.href = '/registro.html');
        });
    },

    async checkAuthStatus() {
        try {
            const user = await Auth.getCurrentUser();
            if (user) {
                this.updateUIForAuthenticatedUser(user);
            } else {
                this.updateUIForUnauthenticatedUser();
            }
        } catch (error) {
            console.error('Auth check error:', error);
        }
    },

    updateUIForAuthenticatedUser(user) {
        // Hide login/registro buttons
        document.querySelectorAll('[data-nav="login"], [data-nav="registro"]').forEach(el => {
            el.style.display = 'none';
        });

        // Show user-specific elements
        document.querySelectorAll('.auth-user-only').forEach(el => {
            el.style.display = 'block';
        });

        // Update user name/info if possible
        const userNameElements = document.querySelectorAll('.user-name');
        userNameElements.forEach(el => {
            el.textContent = user.user_metadata?.full_name || user.email;
        });
    },

    updateUIForUnauthenticatedUser() {
        // Show login/registro buttons
        document.querySelectorAll('[data-nav="login"], [data-nav="registro"]').forEach(el => {
            el.style.display = 'block';
        });

        // Hide user-specific elements
        document.querySelectorAll('.auth-user-only').forEach(el => {
            el.style.display = 'none';
        });
    }
};

// Initialize the app when DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});