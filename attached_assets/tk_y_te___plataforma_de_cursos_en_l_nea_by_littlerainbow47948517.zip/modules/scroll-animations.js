export const ScrollAnimations = {
    init() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                    
                    // Add specific animation classes based on data attribute
                    const animationType = entry.target.dataset.scrollAnimation;
                    if (animationType) {
                        entry.target.classList.add(`animate-${animationType}`);
                    }
                }
            });
        }, {
            threshold: 0.1 // Trigger when 10% of the element is visible
        });

        // Select all elements with scroll animation
        const animatedElements = document.querySelectorAll('.scroll-animate');
        animatedElements.forEach(el => observer.observe(el));
    }
};