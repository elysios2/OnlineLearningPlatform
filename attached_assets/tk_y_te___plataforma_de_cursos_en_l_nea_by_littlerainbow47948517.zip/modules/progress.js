// Progress Module
import { supabase } from '../config/supabaseClient.js';

export const Progress = {
    async trackCourseProgress(courseId, lessonId, progress) {
        try {
            const user = await Auth.getCurrentUser();
            if (!user) throw new Error('No authenticated user');

            const { data, error } = await supabase
                .from('course_progress')
                .upsert({
                    user_id: user.id,
                    course_id: courseId,
                    lesson_id: lessonId,
                    progress: progress
                });

            if (error) throw error;

            return { success: true, data };
        } catch (error) {
            console.error('Track progress error:', error);
            return { success: false, error: error.message };
        }
    },

    async getUserCourseProgress(courseId) {
        try {
            const user = await Auth.getCurrentUser();
            if (!user) throw new Error('No authenticated user');

            const { data, error } = await supabase
                .from('course_progress')
                .select('*')
                .eq('user_id', user.id)
                .eq('course_id', courseId);

            if (error) throw error;

            return data;
        } catch (error) {
            console.error('Get course progress error:', error);
            return [];
        }
    }
};

