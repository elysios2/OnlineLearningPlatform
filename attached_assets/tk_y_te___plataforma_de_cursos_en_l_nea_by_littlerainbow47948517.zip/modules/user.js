// User Module
import { supabase } from '../config/supabaseClient.js';

export const User = {
    async getUserProfile() {
        try {
            const user = await Auth.getCurrentUser();
            if (!user) return null;

            const { data, error } = await supabase
                .from('users')
                .select('*')
                .eq('id', user.id)
                .single();

            if (error) throw error;

            return data;
        } catch (error) {
            console.error('Get user profile error:', error);
            return null;
        }
    },

    async updateUserProfile(updates) {
        try {
            const user = await Auth.getCurrentUser();
            if (!user) throw new Error('No authenticated user');

            const { data, error } = await supabase
                .from('users')
                .update(updates)
                .eq('id', user.id);

            if (error) throw error;

            return { success: true, data };
        } catch (error) {
            console.error('Update profile error:', error);
            return { success: false, error: error.message };
        }
    }
};

