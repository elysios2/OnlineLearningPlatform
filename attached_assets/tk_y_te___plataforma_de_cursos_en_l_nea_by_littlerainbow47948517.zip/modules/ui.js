// UI Module
export const UI = {
    showNotification(message, type = 'info') {
        const notificationContainer = document.createElement('div');
        notificationContainer.classList.add('fixed', 'top-4', 'right-4', 'z-50', 'p-4', 'rounded', 'shadow-lg', 'transition-all');
        
        switch(type) {
            case 'success':
                notificationContainer.classList.add('bg-green-500', 'text-white');
                break;
            case 'error':
                notificationContainer.classList.add('bg-red-500', 'text-white');
                break;
            default:
                notificationContainer.classList.add('bg-blue-500', 'text-white');
        }

        notificationContainer.textContent = message;
        document.body.appendChild(notificationContainer);

        // Remove notification after 3 seconds
        setTimeout(() => {
            notificationContainer.classList.add('opacity-0');
            setTimeout(() => {
                document.body.removeChild(notificationContainer);
            }, 500);
        }, 3000);
    },

    toggleLoader(show = true) {
        let loader = document.getElementById('global-loader');
        if (!loader) {
            loader = document.createElement('div');
            loader.id = 'global-loader';
            loader.classList.add('fixed', 'top-0', 'left-0', 'w-full', 'h-full', 'bg-black', 'bg-opacity-50', 'flex', 'items-center', 'justify-center', 'z-50');
            loader.innerHTML = `
                <div class="animate-spin rounded-full h-32 w-32 border-t-2 border-brand-orange-500"></div>
            `;
            document.body.appendChild(loader);
        }

        loader.style.display = show ? 'flex' : 'none';
    },

    animateElement(element, animationClass) {
        element.classList.add(animationClass);
        element.addEventListener('animationend', () => {
            element.classList.remove(animationClass);
        }, { once: true });
    }
};