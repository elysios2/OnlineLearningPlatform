## Backend Setup
1. Create a Supabase project
2. Replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_ANON_KEY` in `main.js`
3. Create the following tables in Supabase:
   - `users` table with columns:
     * `id` (primary key, references auth.users)
     * `email` (text)
     * `full_name` (text)
     * `created_at` (timestamp)
   - Enable Row Level Security (RLS)

## Database Schema
```sql
-- Users Table
CREATE TABLE users (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

